﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using NetCoreWeb.Models;
using System.Threading;

namespace NetCoreWeb.Controllers
{
    public class HomeController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }


      //有时间研究这个方法
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }

        public IActionResult About()
        {
            ViewData["Message"] = "Your application description page.";
            Thread.Sleep(200);
            int n;
            for (n = 1; n <= 10; n++)
            {
                ViewData["number"] = n;
            }
            return View();
        }

        //创建数据库相关的页面
        public IActionResult Database()
        {
            return View();
        }
    }
}
